/*
 * calibration.c
 *
 *  Created on: Apr 29, 2019
 *      Author: Ocanath
 */
#include "calibration.h"
#include "mag-encoder.h"
#include "i2c.h"

void print_float(float v)
{
	uint8_t * ptr = (uint8_t * )(&v);
	HAL_UART_Transmit(&huart2, ptr, 4, 10);
}
void print_str(const char * str)
{
	int strlen;
	for(strlen=0;str[strlen] != 0; strlen++);
	HAL_UART_Transmit(&huart2, (uint8_t*)str, strlen, 10);
}

static float time_seconds()
{
	return ((float)HAL_GetTick())*.001f;
}

void obtain_encoder_midpoints()
{
	TIMER_UPDATE_DUTY(500,500,500);
	float t_start = time_seconds();
	uint16_t s_max = 0;
	uint16_t s_min = 4096;
	uint16_t c_max = 0;
	uint16_t c_min = 4096;
	while(time_seconds() - t_start < 15)
	{
		if(dma_adc_raw[ADC_SIN_CHAN] > s_max)
			s_max = dma_adc_raw[ADC_SIN_CHAN];
		if(dma_adc_raw[ADC_SIN_CHAN] < s_min)
			s_min = dma_adc_raw[ADC_SIN_CHAN];

		if(dma_adc_raw[ADC_COS_CHAN] > c_max)
			c_max = dma_adc_raw[ADC_COS_CHAN];
		if(dma_adc_raw[ADC_COS_CHAN] < c_min)
			c_min = dma_adc_raw[ADC_COS_CHAN];


		float theta = 420*sin_fast( (fmod_2pi(.2*time_seconds() + PI) - PI) );
		theta = fmod_2pi(theta + PI) - PI;		//re-modulate theta_m. ensure that the angle is constrained from -pi to pi!!
		float sin_theta = sin_fast(theta);				//calculate the sin of the electrical (magnetic flux) angle
		float cos_theta = cos_fast(theta);				//and the cosine for park and inverse park domains
		float i_alpha,i_beta;
		uint32_t tA,tB,tC;
		inverse_park_transform(enc_mid_voltage_amp, 0, sin_theta, cos_theta, &i_alpha, &i_beta);	//maybe call theta rel again?
		svm(i_alpha,i_beta,TIM1->ARR, &tA, &tB, &tC);
		TIMER_UPDATE_DUTY(tA,tB,tC);
	}
	TIMER_UPDATE_DUTY(0,0,0);
	sin_mid = (s_max + s_min)/2;
	cos_mid = (c_max + c_min)/2;
}

/*
 * Ramp up until steady state speed is high
 * Record the beginning and end of the run after SS speed is hit
 * return the average speed
*/
float run_v(float v, uint32_t run_time, float * run_distance)
{
	for(uint32_t stop_ts = HAL_GetTick() + 100; HAL_GetTick()<stop_ts;)	//initial run for SS
		sinusoidal(v, 0);	//todo: replace this with a voltage control mode call

	float run_start = gl_theta_m;
	for(uint32_t stop_ts = HAL_GetTick() + run_time; HAL_GetTick()<stop_ts;)	//the run
		sinusoidal(v, 0);
	float run_end = gl_theta_m;
	TIMER_UPDATE_DUTY(0,0,0);
	HAL_Delay(50);
	*run_distance = run_end - run_start;
	float run_time_f = ((float)run_time);
	float run_speed = *run_distance/run_time_f;
	return abs_f( run_speed ); //proportional to percent error when you replace TAU with V as in voltage
}

/*
 *Automatically find the encoder offset
 */
void auto_calibrate_motor(void)
{
	TIMER_UPDATE_DUTY(0,0,0);
//	align_offset = -PI/elec_conv_ratio;
	align_offset = -.1f;
	int passcount = 0;
	while(1)
	{
		float v = .5f;
		float run_dist_1,run_dist_2;
		float run1_err = run_v(v,400, &run_dist_1);
		float run2_err = run_v(-v,400, &run_dist_2);

		float sign = 0.f;
		if(run_dist_1 > 0.f && run_dist_2 < 0.f)
			sign = 1.f;
		else if (run_dist_1 < 0 && run_dist_2 > 0)
			sign = -1.f;

		double err = run1_err-run2_err;
		double u = err/7.0;

		align_offset += u*sign;
		if(abs_f(u) < 0.0001f)
		{
			passcount++;
			HAL_GPIO_WritePin(STAT_PORT,STAT_PIN,1);
		}
		else
			HAL_GPIO_WritePin(STAT_PORT,STAT_PIN,0);
		if(passcount > 10)
			break;
	}
}


void test_foc()
{
	uint32_t reverse_ts = 0;
	float iq_ref = 70.f;
	for(int i = 0; i < 20; i ++)
	{
		HAL_GPIO_TogglePin(STAT_PORT,STAT_PIN);
		HAL_Delay(100);
	}
	uint32_t tstart = HAL_GetTick();
	uint32_t disp_ts = tstart;
	uint32_t led_ts = HAL_GetTick();
	while(1)
	{

		if(HAL_GetTick() > disp_ts)
		{
////			HAL_GPIO_WritePin(ENABLE_PORT,ENABLE_PIN,0);
//			float t = ((float)(HAL_GetTick()-tstart))*.001f;
//			iq_ref = 80.7f*sin_fast(fmod_2pi(t*3.33f+PI)-PI);
//
			print_float(i_q_meas);
			print_float(gl_dq);
			print_float(align_offset);
//			//			print_float(-.0480f*abs_f(i_q_meas) + 0.7336f);
			disp_ts = HAL_GetTick() + 20;
		}

		if(HAL_GetTick()>led_ts)
		{
			HAL_GPIO_TogglePin(STAT_PORT,STAT_PIN);
			led_ts = HAL_GetTick() + 250;
		}
		if(HAL_GetTick()>reverse_ts)
		{

			iq_ref = -iq_ref;
			uint32_t halt_ts = HAL_GetTick()+250;
			while(HAL_GetTick()<halt_ts)
				foc(0,0);
			reverse_ts = HAL_GetTick()+3000;
//			HAL_GPIO_TogglePin(STAT_PORT,STAT_PIN);
		}

		foc(iq_ref,0);
	}
}

enum {VERIFY_FAILED, VERIFY_PASSED, VERIFY_TIMEOUT};
void force_encoder_region()
{
	HAL_GPIO_WritePin(STAT_PORT,STAT_PIN,1);
	uint8_t retc = VERIFY_FAILED;
	float tau = 5.0f;
	while(retc != VERIFY_PASSED)
	{
		retc = verify_encoder_region(tau, 0.33f, 3, 500);
		if(retc == VERIFY_FAILED)
		{
			theta_enc_prev -= TWO_PI;	//put the encoder in the correct region
		}
		if(retc == VERIFY_TIMEOUT)
		{
			if(tau > 0)
			{
				tau+=5.0f;
				if(tau > 50.0f)
					tau = 50.0f;
			}
			if(tau < 0)
			{
				tau -= 5.0f;
				if(tau < -50.0f)
					tau = -50.0f;
			}
			tau = -tau;
		}
	}
	HAL_GPIO_WritePin(STAT_PORT,STAT_PIN,0);
}

uint8_t verify_encoder_region(float tau, float diff_thresh, int pass_count_thresh, uint32_t timeout)
{
	float theta_m = unwrap(theta_abs_rad(), &theta_m_prev)*.5f;	//get current motor position
	uint32_t tau_switch_ts = HAL_GetTick();
	float pos_prev = theta_m;
	int pass_count = 0;
	while(1)
	{
		theta_m = unwrap(theta_abs_rad(), &theta_m_prev)*.5f;	//get current motor position
//		i2c_tx_data.v = theta_m;
		foc(tau,0);

		float diff = theta_m - pos_prev;
		if(abs_f(diff) >= diff_thresh)
		{
			pos_prev = theta_m;
			if((tau > 0 && diff > diff_thresh) || (tau < 0 && diff < -diff_thresh))
			{
				pass_count++;
				HAL_GPIO_WritePin(STAT_PORT,STAT_PIN,0);
			}
			else
			{
				pass_count--;
				HAL_GPIO_WritePin(STAT_PORT,STAT_PIN,1);
			}
			tau = -tau;
			tau_switch_ts = HAL_GetTick();	//TODO: instead of time, move the rotor so the change in position is at least diff_thresh
		}
		if((HAL_GetTick() - tau_switch_ts) > timeout)
		{
			//			tau=-tau;
			//			pos_prev = theta_m;
			//			tau_switch_ts = HAL_GetTick();
			return VERIFY_TIMEOUT;
		}

		if(pass_count >= pass_count_thresh)
			return VERIFY_PASSED;
		else if (pass_count <= -pass_count_thresh)
			return VERIFY_FAILED;

//		int rc = handle_i2c(&hi2c1);
//		if(hi2c1.ErrorCode != 0 || rc != 0)
//		{
//			HAL_NVIC_ClearPendingIRQ(I2C1_EV_IRQn);				//and maybe doing this are critical for i2c_IT error recovery
//			while(HAL_NVIC_GetPendingIRQ(I2C1_EV_IRQn)==1);
//			I2C1_Reset();
//			gl_i2c_mode = I2C_MODE_WAIT;
//		}
	}

}
